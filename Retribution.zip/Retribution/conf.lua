--256x244

function love.conf(game)
  game.window.width=512
  game.window.height=488
end
